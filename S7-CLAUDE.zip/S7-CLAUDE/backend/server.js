/**
 * Research Paper Recommendation — Express API Server
 * Serves paper data as a REST API consumed by the React frontend.
 *
 * Endpoints:
 *   GET  /api/health          Health check
 *   GET  /api/papers          All papers (with optional ?q=, ?category=, ?topic=, ?year=, ?sort= filters)
 *   GET  /api/papers/:id      Single paper by ID
 *   GET  /api/papers/:id/related  Related papers (same category/topics)
 *   GET  /api/topics          All unique research topics
 *   GET  /api/categories      All unique categories
 *   GET  /api/years           All unique publication years
 */

const express = require("express");
const cors = require("cors");
const papers = require("./data/papers");

const app = express();
const PORT = process.env.PORT || 3001;

// ─── Middleware ────────────────────────────────────────────────────────────────

app.use(cors({ origin: ["http://localhost:5173", "http://127.0.0.1:5173"] }));
app.use(express.json());

// ─── Helpers ──────────────────────────────────────────────────────────────────

const STOP_WORDS = new Set([
  "a","about","above","after","again","all","am","an","and","any","are","at",
  "be","been","being","but","by","can","do","does","doing","down","during",
  "each","few","for","from","get","had","has","have","he","her","here","how",
  "i","if","in","into","is","it","its","just","me","more","most","my","no",
  "not","now","of","on","or","other","our","out","over","she","so","some",
  "such","than","that","the","their","them","then","there","these","they",
  "this","through","to","too","under","up","very","was","we","were","what",
  "when","which","while","who","will","with","would","you","your",
]);

function tokenize(str) {
  return (str || "")
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter((w) => w.length > 2 && !STOP_WORDS.has(w));
}

function scorePaper(paper, tokens) {
  if (!tokens.length) return 1;
  let score = 0;
  const titleTokens = tokenize(paper.title);
  const abstractTokens = tokenize(paper.abstract);
  const topicTokens = paper.topics.flatMap(tokenize);
  const kwTokens = paper.keywords.flatMap(tokenize);

  tokens.forEach((t) => {
    if (titleTokens.some((w) => w.includes(t))) score += 5;
    if (topicTokens.some((w) => w.includes(t))) score += 4;
    if (kwTokens.some((w) => w.includes(t))) score += 3;
    if (abstractTokens.some((w) => w.includes(t))) score += 1;
  });
  return score;
}

function searchPapers({ q, category, topic, year, sort }) {
  let list = [...papers];

  // Text filter
  if (q) {
    const tokens = tokenize(q);
    list = list
      .map((p) => ({ ...p, _score: scorePaper(p, tokens) }))
      .filter((p) => p._score > 0);
    if (sort === "relevance") {
      list.sort((a, b) => b._score - a._score);
    }
  }

  // Category filter
  if (category) {
    list = list.filter((p) => p.category.toLowerCase() === category.toLowerCase());
  }

  // Topic filter
  if (topic) {
    list = list.filter((p) =>
      p.topics.some((t) => t.toLowerCase().includes(topic.toLowerCase()))
    );
  }

  // Year filter
  if (year) {
    list = list.filter((p) => String(p.year) === String(year));
  }

  // Sort
  if (sort === "newest")  list.sort((a, b) => b.year - a.year);
  if (sort === "oldest")  list.sort((a, b) => a.year - b.year);
  if (sort === "title")   list.sort((a, b) => a.title.localeCompare(b.title));

  return list;
}

// ─── Routes ───────────────────────────────────────────────────────────────────

// Health check
app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    timestamp: new Date().toISOString(),
    totalPapers: papers.length,
  });
});

// GET /api/papers — list with optional filters
app.get("/api/papers", (req, res) => {
  const { q = "", category = "", topic = "", year = "", sort = "relevance", limit, offset } = req.query;
  const results = searchPapers({ q, category, topic, year, sort });

  const total = results.length;
  const lim = limit ? parseInt(limit) : undefined;
  const off = offset ? parseInt(offset) : 0;
  const paginated = lim ? results.slice(off, off + lim) : results;

  res.json({
    total,
    count: paginated.length,
    offset: off,
    papers: paginated,
  });
});

// GET /api/papers/:id — single paper
app.get("/api/papers/:id", (req, res) => {
  const id = parseInt(req.params.id);
  const paper = papers.find((p) => p.id === id);
  if (!paper) return res.status(404).json({ error: "Paper not found" });
  res.json(paper);
});

// GET /api/papers/:id/related — related papers by category + topic overlap
app.get("/api/papers/:id/related", (req, res) => {
  const id = parseInt(req.params.id);
  const base = papers.find((p) => p.id === id);
  if (!base) return res.status(404).json({ error: "Paper not found" });

  const related = papers
    .filter((p) => p.id !== base.id)
    .map((p) => {
      let score = 0;
      if (p.category === base.category) score += 3;
      base.topics.forEach((t) => { if (p.topics.includes(t)) score += 1; });
      return { ...p, _score: score };
    })
    .filter((p) => p._score > 0)
    .sort((a, b) => b._score - a._score)
    .slice(0, 6);

  res.json({ total: related.length, papers: related });
});

// GET /api/topics
app.get("/api/topics", (_req, res) => {
  const topics = [...new Set(papers.flatMap((p) => p.topics))].sort();
  res.json(topics);
});

// GET /api/categories
app.get("/api/categories", (_req, res) => {
  const cats = [...new Set(papers.map((p) => p.category))].sort();
  res.json(cats);
});

// GET /api/years
app.get("/api/years", (_req, res) => {
  const years = [...new Set(papers.map((p) => p.year))].sort((a, b) => b - a);
  res.json(years);
});

// 404 handler
app.use((_req, res) => {
  res.status(404).json({ error: "Endpoint not found" });
});

// ─── Start ────────────────────────────────────────────────────────────────────

app.listen(PORT, () => {
  console.log(`\n  ✦  Research Paper API running on http://localhost:${PORT}`);
  console.log(`  ✦  ${papers.length} papers indexed`);
  console.log(`  ✦  Endpoints: /api/health /api/papers /api/topics /api/categories\n`);
});
