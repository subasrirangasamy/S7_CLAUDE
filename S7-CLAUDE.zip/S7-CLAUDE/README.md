# ResearchAI – NLP-Based Research Paper Recommendation System (Frontend)

A frontend-only React + Vite demo. No backend, API keys, or external data needed.
Papers are **illustrative demo records** in `src/data/papers.js` (DOIs and URLs are intentionally empty).
Search and recommendations use simple local text/keyword matching, not real NLP models.

## Run

1. Install Node.js (v18+) from https://nodejs.org if needed.
2. Open this folder in VS Code.
3. Open the terminal inside the folder.
4. `npm install`
5. `npm run dev`
6. Open the local URL shown by Vite (usually http://localhost:5173).

## Features
Dashboard, Search (filters + sorting), Paper Details, Compare 2–4 papers (common / unique topics),
Recommendations, Saved Papers and Search History (both stored in localStorage).
